﻿using baxture_AppService;
using baxture_Entities.Models;
using baxture_Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Cryptography;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    //[Route("api/users")]
    [Authorize]
    public class UsersController : ControllerBase
    {
        private readonly IUserServices _userServices;
        private IConfiguration _config;
        public UsersController(IUserServices userServices, IConfiguration config)
        {
            _userServices = userServices;
            _config = config;

        }



        [HttpGet,Route("GetAllUsers")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAllUsers()
        {
            var users = await _userServices.GetAllUsersAsync();
            return Ok(users);
        }


        [HttpGet, Route("GetUserByIdAsync/{Id}")]
        public async Task<UserModel> GetUserByIdAsync(string Id)
        {

            var result = await _userServices.GetUserByIdAsync(Id);

            return result;


        }

        [HttpPost, Route("CreateUserAsync")]
        public async Task<UserModel> CreateUserAsync(UserModel user)
        {
            var result = await _userServices.CreateUserAsync(user);
            return result;
        }

        //[HttpDelete, Route("DeleteUserAsync/{Id}")]
        //public async Task<UserModel> DeleteUserAsync(string Id )
        //{
        //    return await _userServices.DeleteUserAsync(Id);

        //}


    }
}
