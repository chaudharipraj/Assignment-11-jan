﻿namespace baxture_AppService
{
    public class Class1
    {

    }
}
