﻿using baxture_Entities.Models;
using baxture_Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baxture_AppService
{
    public class UserServices : IUserServices
    {

        private readonly IUserRepository _UserRepo;

        public UserServices(IUserRepository UserRepo)
        {
            _UserRepo = UserRepo;
        }
        public async Task<UserModel> CreateUserAsync(UserModel user)
        {
            return await _UserRepo.CreateUserAsync(user);
        }

        public async Task<bool> DeleteUserAsync(string userId)
        {
            return await _UserRepo.DeleteUserAsync(userId);
           
        }

        public async  Task<IEnumerable<UserModel>> GetAllUsersAsync()
        {
            return await _UserRepo.GetAllUsersAsync();
        }

        public async Task<UserModel> GetUserByIdAsync(string userId)
        {
            return await _UserRepo.GetUserByIdAsync(userId);
        }

        public Task<IEnumerable<UserModel>> SearchUsersAsync(Dictionary<string, string> filters)
        {
            throw new NotImplementedException();
        }

        public Task<UserModel> UpdateUserAsync(string userId, UserModel user)
        {
            throw new NotImplementedException();
        }
    }
}
