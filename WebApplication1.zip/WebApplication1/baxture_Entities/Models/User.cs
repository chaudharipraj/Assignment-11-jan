﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baxture_Entities.Models
{
    public  class User
    {
       // public string Id { get; set; }
        public  string Username { get; set; }
        public  string Password { get; set; }
        //public bool IsAdmin { get; set; } = false;
        //public int Age { get; set; }
        //public List<string> Hobbies { get; set; } = new List<string>();
    }
}
