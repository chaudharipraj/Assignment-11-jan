﻿using baxture_Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baxture_Repositories
{
   public  interface IUserRepository
    {
        Task<UserModel> GetUserByIdAsync(string userId);
        Task<IEnumerable<UserModel>> GetAllUsersAsync();
        Task<UserModel> CreateUserAsync(UserModel user);
        Task<UserModel> UpdateUserAsync(string userId, UserModel user);
        Task<bool> DeleteUserAsync(string userId);
        Task<IEnumerable<UserModel>> SearchUsersAsync(Dictionary<string, string> filters);
    }
}
