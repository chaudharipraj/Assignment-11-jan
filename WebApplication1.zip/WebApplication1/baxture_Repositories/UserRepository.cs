﻿using baxture_Entities.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baxture_Repositories
{
    public class UserRepository : IUserRepository
    {

        private readonly UserContext _dbContext;

        public UserRepository(UserContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<UserModel> CreateUserAsync(UserModel user)
        {

            var existingitem = _dbContext.Users.SingleOrDefault(e => e.Username == user.Username && e.Age == user.Age);
            if (existingitem != null)
            {
                //"Record Already Present"
                return null;
            }
            else
            {
                var result = await _dbContext.Users.AddAsync(user);
                await _dbContext.SaveChangesAsync();
                return result.Entity;
            }
        }

        public async Task<bool> DeleteUserAsync(string userId)
        {
            //bool deleted = await _dbContext.Users.Remove(userId);

            //return deleted;
            return false;
        }

        public async Task<IEnumerable<UserModel>> GetAllUsersAsync()
        {
           return await _dbContext.Users.ToListAsync();
        }

        public async  Task<UserModel> GetUserByIdAsync(string userId)
        {
            return await _dbContext.Users.FirstOrDefaultAsync(e => e.Id == userId);
            
        }

        public Task<IEnumerable<UserModel>> SearchUsersAsync(Dictionary<string, string> filters)
        {
            throw new NotImplementedException();
        }

        public Task<UserModel> UpdateUserAsync(string userId, UserModel user)
        {
            throw new NotImplementedException();
        }
    }
}
